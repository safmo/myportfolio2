﻿namespace Elsys.Decoder;

/// <summary>
/// removed internal by hjo
/// </summary>
public class Data
{
    public double Temperature { get; set; }
    public double Humidity { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Z { get; set; }
    public int Light { get; set; }
    public int Motion { get; set; }
    public int Co2 { get; set; }
    public int Vdd { get; set; }
    public int Analog1 { get; set; }
    public int Lat { get; set; }
    public int Lng { get; set; }
    public int Pulse1 { get; set; }
    public int PulseAbs { get; set; }
    public double ExternalTemperature { get; set; }
    public int Digital { get; set; }
    public int Distance { get; set; }
    public int AccMotion { get; set; }
    public double IrExternalTemperature { get; set; }
    public double IrInternalTemperature { get; set; }
    public int Occupancy { get; set; }
    public int Waterleak { get; set; }
    public double Pressure { get; set; }
    public int SoundAvg { get; set; }
    public int SoundPeak { get; set; }
    public int Pulse2 { get; set; }
    public int PulseAbs2 { get; set; }
    public int Analog2 { get; set; }
    public double ExternalTemperature2 { get; set; }
}