﻿using System;
using System.Threading.Tasks;
using MQTTnet;
using MQTTnet.Client;
using System.Text.Json;
using InfluxDB.Client;
using InfluxDB.Client.Api.Domain;
using InfluxDB.Client.Writes;
using DotNetEnv;
using System.Text;
using ElsysDecoder = Elsys.Decoder.Decoder;
using Elsys.Decoder;

namespace LoRa_TTN
{
    public class Program
    {
        // TTN and MQTT settings
        private static readonly string MqttHost = "eu1.cloud.thethings.network";
        private static readonly int MqttPort = 8883;
        private static readonly string TtnUsername = "campusborlangeelsys";
        private static readonly string TtnPassword;
        private static readonly string TopicFilter = "v3/+/devices/+/up";

        // InfluxDB settings
        private static readonly string InfluxDbUrl = "http://localhost:8086";
        private static readonly string InfluxDbToken;
        private static readonly string InfluxDbOrg;
        private static readonly string InfluxDbBucket;

        private static InfluxDBClient? influxClient;

        static Program()
        {
            // Load environment variables
            DotNetEnv.Env.Load();

            TtnPassword = Environment.GetEnvironmentVariable("TTN_API_KEY")
                ?? throw new InvalidOperationException("TTN_API_KEY not configured in .env file.");

            InfluxDbToken = Environment.GetEnvironmentVariable("INFLUXDB_TOKEN")
                ?? throw new InvalidOperationException("INFLUXDB_TOKEN not configured in .env file.");

            InfluxDbOrg = Environment.GetEnvironmentVariable("INFLUXDB_ORG")
                ?? throw new InvalidOperationException("INFLUXDB_ORG not configured in .env file.");

            InfluxDbBucket = Environment.GetEnvironmentVariable("INFLUXDB_BUCKET")
                ?? throw new InvalidOperationException("INFLUXDB_BUCKET not configured in .env file.");
        }

        public static async Task Main(string[] args)
        {
            Console.WriteLine("Initializing IoT Monitoring Application...");

            influxClient = InfluxDBClientFactory.Create(InfluxDbUrl, InfluxDbToken);

            var mqttFactory = new MqttFactory();
            var mqttClient = mqttFactory.CreateMqttClient();

            var mqttOptions = new MqttClientOptionsBuilder()
                .WithClientId(Guid.NewGuid().ToString())
                .WithTcpServer(MqttHost, MqttPort)
                .WithCredentials(TtnUsername, TtnPassword)
                .WithTlsOptions(o => o.WithAllowUntrustedCertificates(true))
                .Build();

            mqttClient.ConnectedAsync += async e =>
            {
                Console.WriteLine("Connected to MQTT broker.");
                await mqttClient.SubscribeAsync(TopicFilter);
                Console.WriteLine($"Subscribed to topic: {TopicFilter}");
            };

            mqttClient.ApplicationMessageReceivedAsync += async e =>
            {
                var payload = Encoding.UTF8.GetString(e.ApplicationMessage.PayloadSegment);
                Console.WriteLine($"Received payload: {payload}");

                try
                {
                    var jsonDoc = JsonDocument.Parse(payload);
                    var deviceId = jsonDoc.RootElement
                        .GetProperty("end_device_ids")
                        .GetProperty("device_id")
                        .GetString();

                    if (string.IsNullOrEmpty(deviceId))
                    {
                        Console.WriteLine("Device ID missing in message, skipping.");
                        return;
                    }

                    var encodedPayload = jsonDoc.RootElement
                        .GetProperty("uplink_message")
                        .GetProperty("frm_payload")
                        .GetString();

                    if (string.IsNullOrEmpty(encodedPayload))
                    {
                        Console.WriteLine("Payload is empty, skipping.");
                        return;
                    }

                    var decodedBytes = Convert.FromBase64String(encodedPayload);
                    var hexPayload = BitConverter.ToString(decodedBytes).Replace("-", "");
                    var sensorData = ElsysDecoder.Decode(hexPayload);

                    ProcessAllSensorData(deviceId, sensorData);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing message: {ex.Message}");
                }
            };

            try
            {
                await mqttClient.ConnectAsync(mqttOptions);
                Console.WriteLine("Waiting for messages...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect to MQTT broker: {ex.Message}");
            }
        }

        private static void ProcessAllSensorData(string deviceId, Data sensorData)
        {
            Console.WriteLine($"Device: {deviceId}, Temperature: {sensorData.Temperature}°C, External Temp: {sensorData.ExternalTemperature}°C, Humidity: {sensorData.Humidity}%, Pressure: {sensorData.Pressure} hPa, Battery: {sensorData.Vdd / 1000.0}V, X: {sensorData.X}, Y: {sensorData.Y}, Z: {sensorData.Z}, CO2: {sensorData.Co2}, Light: {sensorData.Light}, Motion: {sensorData.Motion}");
            SaveData(deviceId, sensorData);
        }

        private static void SaveData(string deviceId, Data sensorData)
        {
            var point = PointData.Measurement("sensor_data")
                .Tag("device_id", deviceId)
                .Field("temperature", sensorData.Temperature)
                .Field("external_temperature", sensorData.ExternalTemperature)
                .Field("humidity", sensorData.Humidity)
                .Field("pressure", sensorData.Pressure)
                .Field("battery", sensorData.Vdd / 1000.0)
                .Field("x", sensorData.X)
                .Field("y", sensorData.Y)
                .Field("z", sensorData.Z)
                .Field("co2", sensorData.Co2)
                .Field("light", sensorData.Light)
                .Field("motion", sensorData.Motion)
                .Timestamp(DateTime.UtcNow, WritePrecision.Ns);

            try
            {
                var writeApi = influxClient!.GetWriteApiAsync();
                writeApi.WritePointAsync(point, InfluxDbBucket, InfluxDbOrg).Wait();
                Console.WriteLine("Data saved to InfluxDB.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving data to InfluxDB: {ex.Message}");
            }
        }
    }
}

